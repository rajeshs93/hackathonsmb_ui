import React from 'react'

const Review = ({text}) => {
    return (
        <>
        <br/> 
        <p className='review-text'>"{text}"</p>
        </>
    )
}
export default Review