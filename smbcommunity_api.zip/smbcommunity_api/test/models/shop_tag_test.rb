require 'test_helper'

class ShopTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
