class CreateReviews < ActiveRecord::Migration[6.0]
  def change
    create_table :reviews do |t|
      t.integer :shop_id
      t.string :text

      t.timestamps
    end
  end
end
