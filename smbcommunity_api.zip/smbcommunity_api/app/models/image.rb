class Image < ApplicationRecord
    belongs_to :shop
end
